int main(){

    int a=23,b;
    b = 19;
    int product = a*b;
    int add = a+b;
    int ps = a*(a-b);
    int div = a/b;
    printf("Args : a = %d, b = %d, ..\n", a, b);
    printf("The answear:\n");
    printf("    product = %d\n", product);
    printf("    add = %d\n",add);
    printf("    prodcuct sub = %d\n", ps);
    printf("    div = %d\n", div);
    return 0;
}