int main(){
    int q, p=3;
    q = -5+(2*3);
    printf("2 int q = %d, p = %d\n", q, p);
    if (q<=p){
        printf("q <= p\n");
        if(q < p){
            printf("q < p\n");
        }else{
            printf("q == p\n");
        }
    }

    printf("End\n");
    return 0;
}